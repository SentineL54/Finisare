$( function() {
  $( "#sortable" ).sortable();
  $( "#sortable" ).disableSelection();
} );
