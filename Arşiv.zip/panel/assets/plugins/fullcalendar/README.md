
# FullCalendar [![Build Status](https://travis-ci.com/fullcalendar/fullcalendar.svg?branch=master)](https://travis-ci.com/fullcalendar/fullcalendar)

A full-sized drag & drop JavaScript event calendar

- [Project website and demos](http://fullcalendar.io/)
- [Documentation](http://fullcalendar.io/docs)
- [Support](http://fullcalendar.io/support)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)
- [License](LICENSE.txt)

*From the blog*: [Changes in the Upcoming v5](https://fullcalendar.io/blog/2020/02/changes-in-the-upcoming-v5)
