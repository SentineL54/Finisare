<?php




class dashboard {

      public function readBring(){
             echo 'dashboardd -> ekranı model bölümü';
      }
}
