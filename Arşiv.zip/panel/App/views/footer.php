            <div class="page-footer">
                <div class="row">

                      <div class="col-xl-6 col-lg-6 col-md-6 hidden-sm hidden-xs text-left yazi_400">
                          <span class="footer-text Chakra">© Tüm Hakları Saklıdır.</span><br/>
                          <strong class="yazi_600">2013 - <?=date('Y')?> | Sürüm v.1</strong>
                      </div>
                      <div class="col-xl-6 col-lg-6 col-md-6 hidden-sm hidden-xs text-right">
                           <a href="<?=link?>" target="_blank">
                              <img src="<?=favicon?>" style="width:2.7vh;" />
                           </a>
                      </div>
                      <div class="text-center hidden-xl hidden-lg hidden-md col-sm-12 col-xs-12">
                           <div class="boyutla sifirla">
                                 <span class="footer-text Chakra">© Tüm Hakları Saklıdır.</span><br/>
                                 <strong class="yazi_600">2013 - <?=date('Y')?> | Sürüm v.1</strong>
                           </div>
                           <div class="boyutla margin-top-10">
                                 <a href="<?=link?>" target="_blank" >
                                    <img src="<?=favicon?>" style="width:2.7vh;" />
                                 </a>
                           </div>
                      </div>

                </div>
            </div>
      </div>
</div>
