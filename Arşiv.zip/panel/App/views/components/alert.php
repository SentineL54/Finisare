<div class="alert boyutla text-center alert-<?php print $data['value']; ?>" role="alert">
     <span class="Chakra" style="<?php print $data['style']; ?>">
           <?php print $data['message']; ?>
     </span>
</div>
