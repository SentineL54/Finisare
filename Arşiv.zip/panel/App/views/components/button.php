<button type="button" class="btn btn-<?=$data[0]?> <?=$data['class']?>" style="<?=$data['style']?>"><?=$data[1]?></button>
