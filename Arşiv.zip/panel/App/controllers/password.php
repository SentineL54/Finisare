<?

class password extends Controller {


      public function __construct(){
             $wefwf = 'wefwef';
      }

      public function start(){
             echo 'SAKARYA';
      }

}
