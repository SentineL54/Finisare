<?php



class dashboard extends Controller {

      private $viewFolder = 'dashboard';

      private $modelName = 'dashboard';
      
      /*
      private $viewFolder = 'dashboard';

      private $modelName = 'dashboard';

      public function __construct(){

             // echo __CLASS__.'<br>';
             // $this -> nameSpace = '\\App\\Models\\Pages\\Dashboard\\';


             $this -> model = $this -> model( $this->modelName , 'pages' , $this -> nameSpace );


             // $this -> model -> readBring();
      } */

      public function start(){

           echo 'wefwefw';
            // $this->model->readBring();
            // $this -> view( $this -> viewFolder , NULL , 'pages/' );

      }
}
